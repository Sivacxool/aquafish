# AquaHatch 0.4.0 — กล้องในเครื่องและตรวจนับลูกปลา

Flutter Android + FastAPI Gateway + MQTT รวมระบบสั่งกล้องจากแชทอ้างอิงเข้ากับ UI แบบ 3 ขั้นและการแก้บั๊กฟอร์มเชื่อมต่อ 0.3.1

## สิ่งที่เปลี่ยน

- หน้านับลูกปลาเริ่มจากกล้องในเครื่อง กดสั่งถ่ายใหม่ผ่าน Gateway และรอ JPEG ของรหัสงานเดียวกัน แสดงเวลาที่ Gateway รับภาพ
- ไม่เปิดภาพตัวอย่างแทนกล้องจริงโดยอัตโนมัติ กล้องมือถือ/เลือกภาพ/คลิปเป็นทางเลือก ภาพตัวอย่างต้องกดเลือกเอง
- ภาพที่รับเปิดนับด้วยมือหรือส่งเข้าโมเดล AI ที่ Gateway ได้ ตรวจแก้จุด/ซูม/ย้อนกลับ/ยืนยัน/บันทึกในหน้าตรวจผลเดิม
- ล้างภาพเมื่อเริ่มถ่ายใหม่หรือเปลี่ยนเครื่อง ไม่รับภาพเก่าที่กลับมาหลังเปลี่ยนการเชื่อมต่อ
- Dashboard มีทางลัดกล้องและสถานะกล้องแยกจากบอร์ดควบคุม ปรับสีกรมท่า–เขียวอมฟ้า การ์ดค่าและรอบฟักให้ชัดขึ้น
- คงการแก้ PageStorage ของฟอร์ม URL/รหัส และเงื่อนไข freshness/interlock/manual lease/ACK เดิม

กล้องเป็นภาพนิ่งตามคำสั่ง ยังไม่มีวิดีโอสดต่อเนื่อง ไม่มี weights AI ลูกปลาที่ฝึกแล้ว และยังไม่มีเฟิร์มแวร์ควบคุมฮีตเตอร์/ปั๊มที่ยืนยันกับอุปกรณ์จริงของผู้ใช้

## เริ่มใช้

อ่าน `docs/CAMERA-START-TH.md` ก่อน แล้วตั้งค่าตาม `firmware/CAMERA_SETUP.md` ใช้ Gateway และ APK รุ่น 0.4.0 คู่กัน

`firmware/camera_node/` มี source กล้อง ESP32-S3 รับ MQTT และอัปโหลด JPEG ต้องกรอก `config.h` ตามบอร์ดจริงก่อน build ค่าเริ่มต้นตั้งใจหยุด compile จนยืนยัน GPIO ชื่อ ESP32-S3 + OV5640 ยังไม่เพียงพอระบุ pin map ชุดนี้ไม่มี `.bin` ให้แฟลชโดยเดารุ่น

`firmware/PROTOCOL.md` เป็นสัญญา telemetry/คำสั่งของบอร์ดควบคุม ส่วน MQTT ของกล้องอยู่ใน CAMERA_SETUP.md บอร์ดควบคุมและบอร์ดกล้องแยกสถานะกันได้

## ตรวจซอฟต์แวร์

ใช้ Flutter 3.44.6 / Dart 3.12.2

```powershell
flutter pub get
flutter analyze
flutter test
flutter build apk --release --target-platform android-arm64 --split-per-abi
```

เมื่อไม่รัน Gateway ชุดทดสอบ optional จะข้าม 2 เคส ไม่ได้นับว่าเป็นผลทดสอบฮาร์ดแวร์

ทดสอบ Gateway จากโฟลเดอร์ gateway โดยสร้าง venv และติดตั้ง `requirements.txt` กับ pytest แล้วรัน `python -m pytest -q`

เพื่อทดสอบ HTTP camera round trip จาก source ชุดนี้โดยไม่มีบอร์ด ให้เปิด 2 หน้าต่าง จาก root aqua_hatch:

```powershell
# หน้าต่าง 1 — ทดสอบในคอมเครื่องนี้เท่านั้น
python -m venv gateway/.venv
./gateway/.venv/Scripts/python.exe -m pip install -r gateway/requirements.txt pytest
./gateway/.venv/Scripts/python.exe gateway/tools/software_camera.py --config-file gateway/camera-test-config.json
```

```powershell
# หน้าต่าง 2
flutter test --dart-define-from-file=gateway/camera-test-config.json
```

เครื่องมือนี้สร้าง JPEG วาดทดสอบ ระบุ SOFTWARE CAMERA TEST และจำลองขาที่ส่ง MQTT เท่านั้น HTTP/การตรวจสิทธิ์/การเก็บและอ่าน JPEG ใช้โค้ดจริง ไม่ได้ทดสอบ Broker หรือกล้องจริง ปิดด้วย Ctrl+C และอย่าใช้เครื่องมือจำลองนี้แทน Gateway สำหรับฮาร์ดแวร์

## การสร้าง APK และลายเซ็น

APK ชุดส่งมอบใช้ development certificate เดียวกับ APK 0.2 ของผู้ใช้ package เดิมและ version code สูงขึ้น ตรวจข้อมูลลายเซ็นแล้ว แต่ยังไม่ได้ทดสอบติดตั้ง/อัปเดตบน Android จริง ไม่รวม private keystore ใน source การ build ด้วย key อื่นจะอัปเดตทับ APK ชุดนี้ไม่ได้

Android ต้องเป็น arm64 และ API 24 ขึ้นไป iOS ยังไม่ได้ build/test

## ขอบเขต

อ่าน VERIFICATION.md สำหรับผลตรวจจริง ไม่มีผลทดสอบ ESP32/OV5640 จริง ผังขากล้องและวงจรควบคุมยังรอรุ่นอุปกรณ์ ไม่มี Push ตอนปิดแอป QR/ค้นหาเครื่องอัตโนมัติ หรือโมเดล AI ใหม่ ระบบนี้ยังใช้ Gateway สำหรับเครื่องเดียวและ development auth ต้องจัดการ deployment/auth ของเจ้าของระบบก่อนใช้ภายนอก
