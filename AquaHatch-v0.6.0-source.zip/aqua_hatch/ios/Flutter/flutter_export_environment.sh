#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=C:\flutter"
export "FLUTTER_APPLICATION_PATH=C:\Users\godis\Documents\Codex\2026-10-15\ui-ux\work\aquahatch-v04\aqua_hatch"
export "FLUTTER_FRAMEWORK_SWIFT_PACKAGE_PATH=C:\Users\godis\Documents\Codex\2026-10-15\ui-ux\work\aquahatch-v04\aqua_hatch\ios\Flutter\ephemeral\Packages\.packages\FlutterFramework"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_TARGET=lib\main.dart"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=0.3.1"
export "FLUTTER_BUILD_NUMBER=4"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=.dart_tool/package_config.json"
