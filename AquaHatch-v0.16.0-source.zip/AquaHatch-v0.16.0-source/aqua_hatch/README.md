# AquaHatch 0.16.0

ซอร์สแอป Flutter, เฟิร์มแวร์ ESP32-WROOM-DA และ ESP32-CAM

- [เริ่มใช้งานและดาวน์โหลด](../README.md)
- [การเชื่อมต่อ 4 ขั้น](../START_HERE_TH.md)
- [เซนเซอร์ DS18B20, DO และ pH](SENSORS_SETUP_TH.md)
- [สร้างชุดสำหรับบอร์ดใหม่](../REBUILD.md)
- [ผลตรวจและข้อจำกัด](../VERIFICATION.md)

จากโฟลเดอร์นี้ใช้ `flutter pub get`, `flutter analyze`, `flutter test`
และ `./tools/Build-Android.ps1` เพื่อสร้าง Android Universal APK
เฟิร์มแวร์สร้างใบรับรองเฉพาะบอร์ดและให้แอปรับผ่าน QR ดู [คู่มือ FirstBoot](../FIRST_BOOT_PAIRING_TH.md)
