package th.ac.aquahatch.aqua_hatch

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
