import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:http/http.dart' as http;
import 'package:web_socket_channel/web_socket_channel.dart';
import 'models.dart';
import 'repository.dart';

class LiveRepository implements DeviceRepository {
  final ConnectionConfig config;
  final String token;
  final http.Client _client;
  final _stream = StreamController<Telemetry>.broadcast();
  final _pending = <String, Completer<CommandResult>>{};
  WebSocketChannel? _socket;
  StreamSubscription<dynamic>? _subscription;
  Timer? _retry;
  DeviceSettings? _settings;
  bool _closed = false;
  int _attempt = 0;
  LiveRepository(this.config, this.token, {http.Client? client})
    : _client = client ?? http.Client();
  @override
  Stream<Telemetry> get telemetry => _stream.stream;
  @override
  DeviceSettings? get reportedSettings => _settings;
  Uri _uri(String suffix) => Uri.parse(
    '${config.baseUrl.replaceAll(RegExp(r'/+$'), '')}/api/v1/devices/${config.deviceId}$suffix',
  );
  Map<String, String> get _headers => {
    'Authorization': 'Bearer $token',
    'Content-Type': 'application/json',
  };
  String _error(http.Response response) {
    try {
      return (jsonDecode(response.body) as Map)['detail']?.toString() ??
          'เซิร์ฟเวอร์ตอบกลับไม่สำเร็จ';
    } catch (_) {
      return 'เซิร์ฟเวอร์ตอบกลับไม่สำเร็จ (HTTP ${response.statusCode})';
    }
  }

  void _snapshot(Map<String, dynamic> data) {
    if (data['config'] is Map) {
      _settings = DeviceSettings.fromJson(
        Map<String, dynamic>.from(data['config'] as Map),
      );
    }
    final raw = data['telemetry'];
    if (raw is Map && !_stream.isClosed) {
      _stream.add(Telemetry.fromJson(Map<String, dynamic>.from(raw)));
    }
  }

  @override
  Future<void> connect() async {
    if (token.trim().isEmpty) {
      throw StateError('ใส่รหัสเข้าถึงเซิร์ฟเวอร์ก่อนเชื่อมต่อ');
    }
    final response = await _client
        .get(_uri(''), headers: _headers)
        .timeout(const Duration(seconds: 8));
    if (response.statusCode != 200) throw StateError(_error(response));
    _snapshot(jsonDecode(response.body) as Map<String, dynamic>);
    await _openSocket();
  }

  Future<void> _openSocket() async {
    if (_closed) return;
    await _subscription?.cancel();
    await _socket?.sink.close();
    var uri = _uri('/stream');
    uri = uri.replace(scheme: uri.scheme == 'https' ? 'wss' : 'ws');
    final channel = WebSocketChannel.connect(uri);
    _socket = channel;
    try {
      await channel.ready.timeout(const Duration(seconds: 8));
      if (_closed) {
        await channel.sink.close();
        return;
      }
      channel.sink.add(jsonEncode({'type': 'auth', 'token': token}));
      _subscription = channel.stream.listen(
        (raw) {
          try {
            final message = jsonDecode(raw as String) as Map<String, dynamic>;
            if (message['type'] == 'telemetry') {
              _attempt = 0;
              _snapshot(message['data'] as Map<String, dynamic>);
            }
            if (message['type'] == 'ack') {
              final data = message['data'] as Map<String, dynamic>;
              final completer = _pending.remove(data['command_id']);
              completer?.complete(
                CommandResult(
                  id: data['command_id'] as String,
                  applied: data['status'] == 'applied',
                  message: data['message'] as String? ?? 'เครื่องตอบกลับแล้ว',
                ),
              );
            }
            if (message['type'] == 'error') {
              _stream.addError(
                StateError(
                  message['message'] as String? ?? 'เชื่อมต่อไม่สำเร็จ',
                ),
              );
            }
          } catch (_) {
            _stream.addError(StateError('รูปแบบข้อมูลจากเครื่องไม่ถูกต้อง'));
          }
        },
        onError: (Object error) {
          _scheduleRetry();
        },
        onDone: _scheduleRetry,
        cancelOnError: true,
      );
    } catch (_) {
      _scheduleRetry();
      rethrow;
    }
  }

  void _scheduleRetry() {
    if (_closed || _retry?.isActive == true) return;
    _stream.addError(StateError('การเชื่อมต่อหลุด กำลังลองใหม่'));
    _attempt++;
    final seconds = (1 << _attempt.clamp(0, 4)).clamp(2, 16);
    _retry = Timer(Duration(seconds: seconds), () async {
      if (_closed) return;
      try {
        await _openSocket();
      } catch (_) {
        _scheduleRetry();
      }
    });
  }

  @override
  Future<CommandResult> command(
    String action,
    Map<String, dynamic> payload,
  ) async {
    final id = createId();
    final completer = Completer<CommandResult>();
    _pending[id] = completer;
    try {
      final response = await _client
          .post(
            _uri('/commands'),
            headers: _headers,
            body: jsonEncode({
              'command_id': id,
              'action': action,
              'payload': payload,
              'expires_at': DateTime.now()
                  .toUtc()
                  .add(const Duration(seconds: 10))
                  .toIso8601String(),
            }),
          )
          .timeout(const Duration(seconds: 8));
      if (response.statusCode != 202) throw StateError(_error(response));
      return await completer.future.timeout(
        const Duration(seconds: 10),
        onTimeout: () => CommandResult(
          id: id,
          applied: false,
          message: 'เครื่องยังไม่ยืนยัน กรุณาตรวจสถานะก่อนส่งใหม่',
        ),
      );
    } finally {
      _pending.remove(id);
    }
  }

  Future<List<Telemetry>> loadHistory() async {
    final response = await _client.get(_uri('/history?limit=1440'), headers: _headers).timeout(const Duration(seconds: 15));
    if (response.statusCode != 200) throw StateError(_error(response));
    return ((jsonDecode(response.body) as Map)['items'] as List).map((e) => Telemetry.fromJson(Map<String, dynamic>.from(e as Map))).toList();
  }
  @override
  Future<AnalysisResult> analyze(
    Uint8List bytes,
    String filename,
    bool video,
  ) async {
    if (bytes.length > 50 * 1024 * 1024) {
      throw StateError('ไฟล์ต้องมีขนาดไม่เกิน 50 MB');
    }
    final request = http.MultipartRequest('POST', _uri('/counts/analyze'))
      ..headers['Authorization'] = 'Bearer $token'
      ..fields['kind'] = video ? 'video' : 'image'
      ..files.add(
        http.MultipartFile.fromBytes('file', bytes, filename: filename),
      );
    final streamed = await _client
        .send(request)
        .timeout(const Duration(seconds: 90));
    final response = await http.Response.fromStream(
      streamed,
    ).timeout(const Duration(seconds: 90));
    if (response.statusCode != 200) throw StateError(_error(response));
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    final points = (data['points'] as List)
        .map((e) => CountPoint.fromJson(e as Map<String, dynamic>))
        .toList();
    return AnalysisResult(
      points,
      data['model_version'] as String,
      frameBytes: data['frame_base64'] == null
          ? null
          : base64Decode(data['frame_base64'] as String),
    );
  }

  @override
  Future<void> dispose() async {
    _closed = true;
    _retry?.cancel();
    for (final entry in _pending.entries) {
      entry.value.complete(
        CommandResult(
          id: entry.key,
          applied: false,
          message: 'การเชื่อมต่อถูกเปลี่ยน',
        ),
      );
    }
    _pending.clear();
    await _subscription?.cancel();
    await _socket?.sink.close();
    _client.close();
    await _stream.close();
  }
}
