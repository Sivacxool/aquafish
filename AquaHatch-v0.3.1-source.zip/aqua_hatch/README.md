# Aqua Hatch 0.3.1 — เครื่องฟักไข่ปลาดุกภาษาไทย

Flutter Android/iOS + FastAPI Gateway + MQTT/WebSocket สี่หน้าหลัก: ภาพรวม ควบคุม นับลูกปลา ตั้งค่า

รุ่นปรับ UI/UX ต่อจาก 0.2 ตรวจ analyze, Flutter tests, เว็บและ Android release build แล้ว ดู VERIFICATION.md สำหรับขอบเขตที่ตรวจได้จริง

## แก้ไขใน 0.3.1

- แก้หน้าตั้งค่าที่ช่อง URL กลายเป็นพื้นที่สีเทาขนาดใหญ่หลังเลือกเครื่องจริง สาเหตุคือสถานะพับ/เปิดหมวดชนกับสถานะเลื่อนของช่องกรอกใน PageStorage
- แยกที่เก็บสถานะของเนื้อหาหมวด และกำหนดรหัสให้ช่อง URL / รหัสเครื่อง / รหัสเข้าถึง เพื่อไม่ให้ใช้สถานะร่วมกัน
- เพิ่ม regression tests ของฟอร์มที่ 390×844 และ 1440×1024 พร้อมตรวจว่ากรอกได้ครบ 3 ช่อง
- คู่มือภาษาไทยอยู่ที่ docs/ESP32-Guide-TH.md เริ่มทดลอง App–Gateway ได้ก่อนมีบอร์ด ส่วน MQTT และ firmware ต้องพัฒนาตามบอร์ด/เซนเซอร์จริง ดู firmware/PROTOCOL.md ประกอบ

## UI/UX ที่ปรับใน 0.3.0
- หน้าแรกแสดงค่าคุณภาพน้ำครบ 4 ค่าได้ในจอ 390×844 ย่อรายละเอียดการเชื่อมต่อให้แตะเปิดดู
- การ์ดรอบฟักเน้นชื่อ เวลา และสถานะ เพิ่มช่วงกราฟ 1/6/24 ชั่วโมง
- เพิ่มความเข้มข้อความรอง ปรับช่องว่างและขนาดตัวอักษรเล็ก
- โหมดอัตโนมัติแสดงสถานะเปิด/ปิดแยกจากสวิตช์สั่งงาน โหมดควบคุมเองมีเวลาคงเหลือและปุ่มกลับอัตโนมัติ
- นับปลาเป็นเลือกภาพ → ตรวจนับ → บันทึก ภาพ จำนวน เครื่องมือซูม/แก้จุด และปุ่มบันทึกอยู่ใกล้กัน
- การแก้จุดและย้อนกลับจะยกเลิกการยืนยันเดิม ต้องตรวจอีกครั้งก่อนบันทึก เก็บที่มาของผล AI/ผลตัวอย่างตามเดิม
- ตั้งค่าแบ่ง 5 หมวด พับเก็บโดยรักษาข้อมูลที่กำลังกรอก และตรวจช่วง pH ใกล้ช่องกรอก

ยังไม่มี Push ตอนปิดแอป, ค้นหาเครื่อง/สแกน QR, โมเดล AI ใหม่ หรือ firmware ใหม่
APK ชุดที่ส่งใช้ development signing certificate เดียวกับ APK 0.2 ของผู้ใช้ ไม่รวม private keystore ไว้ใน source zip การ build จาก source ด้วย key อื่นจะอัปเดตทับ APK นี้ไม่ได้ ต้องตั้งค่า signing ด้วย key เดิมก่อน


## สิ่งที่เปลี่ยน
- ตัดระบบเติมออกซิเจนและ DO จาก UI ค่าตั้ง และคำสั่ง Gateway
- เพิ่ม pH ช่วงต่ำสุด/สูงสุด สถานะ/เวลาสอบเทียบ และแจ้งเตือนเมื่ออ่านไม่ได้หรือเกินช่วง
- หน้าแรกแสดงสถานะเครื่อง เวลารับข้อมูลล่าสุด Wi-Fi/เฟิร์มแวร์เมื่อเครื่องรายงาน และป้ายข้อมูลจำลอง
- ข้อมูลเกิน 15 วินาทีหรือเครื่องออฟไลน์จะไม่ปลดล็อกปุ่มควบคุม
- ประวัติคุณภาพน้ำในมือถือสูงสุด 1,440 จุด ประมาณนาทีละจุด พร้อมคัดลอก CSV
- Gateway เก็บประวัตินาทีละจุด 7 วันใน SQLite ขณะเซิร์ฟเวอร์ทำงานแม้ปิดมือถือ
- เหตุการณ์ล่าสุด 200 รายการเก็บในมือถือ แยกตามการเชื่อมต่อ พร้อมสถานะรับทราบ
- กราฟใช้เวลาจริง เว้นช่วงเมื่อไม่มีข้อมูลเกิน 2 นาที
- รหัสมือถือเก็บเข้ารหัสด้วย flutter_secure_storage; เว้นว่างเพื่อใช้รหัสเดิม ลบได้ในตั้งค่า เว็บใช้เฉพาะ session
- Auto/Manual 5 นาที รอ device ACK พร้อมเงื่อนไขป้องกันในเครื่องจำลอง
- กล้อง ภาพ/คลิป การตรวจแก้จุดนับ และผลนับที่ผู้ใช้ตรวจแล้วอยู่ในแอป

ค่า 28 °C, pH 6.5–8.5, flow 2.4 L/min เป็นค่าเพื่อทดลองซอฟต์แวร์ ผู้ดูแลต้องกำหนดตามกระบวนการจริง ไม่มีระบบเติมสารปรับ pH

## รันและสร้าง Android
ใช้ Flutter 3.44.6 / Dart 3.12.2 ตาม pubspec.lock และ Android SDK ที่รองรับ

~~~sh
flutter pub get
flutter analyze
flutter test
flutter run
flutter build apk --release --split-per-abi
~~~

Windows ใช้ ./Build-Android.ps1 หรือ ./Build-Android.ps1 -Flutter C:\flutter\bin\flutter.bat
สคริปต์หยุดถ้า analyze/test ไม่ผ่าน APK อยู่ที่ build/app/outputs/flutter-apk/
การลงนามปัจจุบันเป็น development key ต้องกำหนด release signing ก่อนเผยแพร่
iOS ต้องใช้ macOS/Xcode และ signing ของเจ้าของแอป ยังไม่ได้ทดสอบ build

## Gateway
ใช้ Python 3.11+ เปิด virtual environment ก่อนติดตั้ง dependencies

~~~powershell
cd gateway
python -m venv .venv
. .venv/Scripts/Activate.ps1
python -m pip install -r requirements.txt pytest
$env:DEV_ACCESS_TOKEN = 'replace-with-your-own-long-random-token'
$env:DEVICE_ID = 'incubator-01'
$env:SIMULATE_DEVICE = '1'
python -m uvicorn main:app --host 127.0.0.1 --port 8000
~~~

ในแอป: ตั้งค่า → เครื่องจริง → URL → รหัสเครื่อง → รหัสเข้าถึงเดียวกัน
- Android emulator: http://10.0.2.2:8000
- USB: adb reverse tcp:8000 tcp:8000 แล้ว URL http://localhost:8000
- เครือข่ายจริงต้อง HTTPS/WSS พร้อมใบรับรองที่มือถือเชื่อถือ
- Gateway จำลองติดป้าย simulated เสมอ
- ฮาร์ดแวร์ใช้ SIMULATE_DEVICE=0 และ MQTT ตาม gateway/.env.example
- ประวัติ: GET /api/v1/devices/incubator-01/history?limit=1440 พร้อม Bearer token
- สำรอง gateway/data/gateway.sqlite เมื่อหยุดเซิร์ฟเวอร์หรือใช้ SQLite backup API ห้ามเก็บ token ใน source control

## ก่อนใช้กับเครื่องจริง
ผู้ใช้ยังไม่ได้เลือกอุปกรณ์ จึงยังไม่มี GPIO/firmware พร้อม flash ต้องกำหนดบอร์ด หัววัด pH อุณหภูมิ/flow/ระดับน้ำ รีเลย์ และโหลดจริงตาม firmware/HARDWARE_SETUP.md และ firmware/PROTOCOL.md

AI ต้องติดตั้งโมเดล YOLO ที่ฝึกกับลูกปลาจริง คลาส larva ถ้าไม่มีโมเดล Gateway จะปฏิเสธ AI ผู้ใช้ยังนับภาพด้วยมือได้ ภาพตัวอย่าง 48 ตัวเป็นการทดลอง คลิปนับจำนวนในเฟรมที่เลือก ไม่บวกจำนวนข้ามเฟรม

แจ้งเตือนมือถือทำงานขณะเปิดแอป ยังไม่มี Push ตอนปิดแอป ไม่มี BLE provisioning/OTA/ระบบผู้ใช้หลายบัญชี Gateway กำหนด token และสิทธิ์หนึ่งเครื่องต่อ instance

## โครงสร้าง
lib/app ธีม/เส้นทาง · lib/core ข้อมูล/เชื่อมต่อ/ประวัติ/รหัสเข้ารหัส · lib/features หน้าจอ · gateway API/MQTT/AI · firmware สัญญาฮาร์ดแวร์ · ml ฝึกโมเดล · test Flutter tests

