﻿AquaHatch 0.17.0 ต้นแบบปั๊มเติมน้ำสำหรับ WROOM-DA
อ่าน PUMP_PROTOTYPE_TH.md และถอดไฟ 12 V ฝั่งปั๊ม/รีเลย์ก่อน
ติดตั้ง Arduino IDE พร้อม Arduino-ESP32 3.3.12 และ Python 3.11 ขึ้นไป
ปิด Serial Monitor ต่อ USB แล้วเปิด Install-WROOM-DA.cmd
ใช้ Read-QR-WROOM-DA.cmd เมื่อต้องการอ่านบัตรจับคู่เดิม
