﻿AquaHatch 0.16.1 สำหรับ WROOM-DA และ ESP32-CAM

ใช้ Arduino-ESP32 3.3.12 และ Python 3.11 ขึ้นไป
1. แตก ZIP ปิด Serial Monitor และต่อบอร์ดทีละตัว
2. เปิด Install-WROOM-DA.cmd หรือ Install-CAM.cmd ตามชนิดบอร์ด
3. อ่านบัตรส่วนตัวด้วย Read-QR ของบอร์ดนั้นเมื่อจำเป็น
4. จับคู่ด้วย AquaHatch จากเมนูตั้งค่า
5. สำหรับดูเซนเซอร์และถ่ายภาพผ่านอินเทอร์เน็ต ดู REMOTE_SETUP_TH.md

บอร์ดหลักใช้ DS18B20 GPIO4, DO GPIO16/17/18, ADS1115 SDA21/SCL22
