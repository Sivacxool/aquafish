AquaHatch 0.14.0 — ลงเฟิร์มแวร์ แล้วรับ QR ประจำบอร์ด

รุ่นที่รองรับ: S3 Flash16MB / OPI PSRAM8MB และ AI Thinker ESP32-CAM ตามชุดเดิม
ต้องมี Arduino IDE / Arduino CLI พร้อม Arduino-ESP32 3.3.12 และ Python3.11ขึ้นไปบน Windows
ตัวช่วยเตรียม pyserial/qrcode ในโฟลเดอร์ส่วนตัว ครั้งแรกต้องใช้อินเทอร์เน็ต

1. แตก ZIP ทั้งโฟลเดอร์ ต่อบอร์ดทีละตัวด้วย USB ปิด Serial Monitor
2. S3 เปิด Install-S3.cmd / กล้องเปิด Install-CAM.cmd กรอก COM ที่ขึ้นจริง
3. โปรแกรมลงไฟล์ ตรวจ checksum แล้วรอบอร์ดสร้างตัวตน เปิดบัตร QR ให้บนคอม
4. แอป0.14.0 > ตั้งค่า > บอร์ดใหม่? สแกน QR เพื่อจับคู่
5. ตรวจชนิดอุปกรณ์ แล้วตั้ง Wi-Fi บ้านตามขั้นตอนของแอป

หากบัตรหาย ใช้ Read-QR-S3.cmd หรือ Read-QR-CAM.cmd เพื่ออ่าน QR เดิม ไม่ต้องลงใหม่
ห้ามแจกบัตร PAIRING_PRIVATE หรือไฟล์ dump NVS/flash ของบอร์ดที่ตั้งค่าแล้ว
ชุดไฟล์นี้เป็น generic ไม่มี token/keys ของผู้ใช้เก่าฝังอยู่ ไม่สั่ง erase-flash
หากล้าง NVS บอร์ดจะได้รหัสและ CA ใหม่ ต้องอ่านและสแกน QR ใหม่

รอบนี้ตรวจคอมไพล์และทดสอบโค้ดบนคอม ยังไม่ได้แฟลชบอร์ดผู้ใช้หรือทดสอบ first boot/NVS จริง
อ่าน FIRST_BOOT_PAIRING_TH.md สำหรับขั้นตอนและข้อจำกัดทั้งหมด
แอป iOS/Android: https://github.com/Sivacxool/aquafish
