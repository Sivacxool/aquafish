"""Package only deliverable files; omit build meshes, backups and printer G-code."""
from pathlib import Path
import csv
import hashlib
import json
import zipfile

OUT = Path(__file__).resolve().parent.parent
geometry = json.loads((OUT / 'geometry_checks.json').read_text(encoding='utf-8'))
with (OUT / 'PRINT_LIST.csv').open('w', encoding='utf-8-sig', newline='') as f:
    writer = csv.writer(f)
    writer.writerow(['file', 'ชิ้นงาน', 'จำนวน', 'ด้านพิมพ์ / หมายเหตุ'])
    for stem, info in geometry['parts'].items():
        qty = str(info['quantity'])
        if stem.startswith(('04_', '05_')):
            qty = 'เลือก 04 หรือ 05 อย่างเดียว 1 ชิ้น'
        writer.writerow([stem, info['name_th'], qty, info['print_note']])

def eligible(path):
    relative = path.relative_to(OUT)
    return path.is_file() and not any(x in ('_build', '__pycache__') for x in relative.parts) and path.suffix not in ('.blend1', '.gcode', '.zip', '.pyc') and path.name not in ('manifest_sha256.json', 'SHA256SUMS.txt')

files = sorted(p for p in OUT.rglob('*') if eligible(p))
manifest = {p.relative_to(OUT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(OUT / 'manifest_sha256.json').write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding='utf-8')
full = OUT / 'AquaHatch_CTRL-LV01_3D_Print_Pack.zip'
with zipfile.ZipFile(full, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=7) as z:
    for p in files + [OUT / 'manifest_sha256.json']:
        z.write(p, 'AquaHatch_CTRL-LV01/' + p.relative_to(OUT).as_posix())

small = OUT / 'AquaHatch_CTRL-LV01_STL.zip'
with zipfile.ZipFile(small, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=7) as z:
    for p in files:
        relative = p.relative_to(OUT)
        if relative.parts[0] == 'STL' or p.name in ('README_TH.md', 'PRINT_LIST.csv', 'VERIFICATION.md'):
            z.write(p, relative.as_posix())

(OUT / 'SHA256SUMS.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest() + '  ' + p.name + '\n' for p in (full, small)), encoding='utf-8')
for p in (full, small):
    with zipfile.ZipFile(p) as z:
        assert z.testzip() is None
        assert not any(n.endswith(('.gcode', '.blend1')) or '/_build/' in n for n in z.namelist())
    print(p.name, round(p.stat().st_size / 1024 / 1024, 2), 'MiB')
print('Packaged', len(files), 'deliverable files with SHA-256 manifest; both ZIP checks passed.')
