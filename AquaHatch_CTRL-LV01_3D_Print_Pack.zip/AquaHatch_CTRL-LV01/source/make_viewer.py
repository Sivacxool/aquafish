"""Build an offline, self-contained viewer from the actual CAD GLB, not a mockup."""
from pathlib import Path
import base64
import json
import shutil

OUT=Path(__file__).resolve().parent.parent
DEPS=Path(__file__).resolve().parent/'vendor/three'


def data(text):
    return 'data:text/javascript;base64,'+base64.b64encode(text.encode()).decode()


imports={}
for name,key in [('three.core.js','three-core'),('three.module.js','three'),('OrbitControls.js','orbit'),('GLTFLoader.js','gltf'),('BufferGeometryUtils.js','buffer-utils'),('SkeletonUtils.js','skeleton-utils')]:
    text=(DEPS/name).read_text(encoding='utf-8').replace("'./three.core.js'","'three-core'").replace("'../utils/BufferGeometryUtils.js'","'buffer-utils'").replace("'../utils/SkeletonUtils.js'","'skeleton-utils'")
    imports[key]=data(text)
glb=base64.b64encode((OUT/'preview/AquaHatch_CTRL-LV01.glb').read_bytes()).decode()
template=r'''<!doctype html>
<html lang="th"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>AquaHatch CTRL–LV01 | กล่องควบคุมพิมพ์ 3D</title>
<style>
*{box-sizing:border-box}body{margin:0;font-family:Tahoma,Arial,sans-serif;background:#e8eff1;color:#143f50}
.app{display:grid;grid-template-columns:300px 1fr;height:100vh}aside{padding:27px 23px;background:#102f3e;color:#edf6f6;overflow:auto}
.brand{font-size:11px;color:#8ad7cc;letter-spacing:2px}h1{font-size:28px;line-height:1.25;margin:23px 0 12px;font-weight:500}h1 b{color:#8ad7cc}
p{font-size:12px;line-height:1.8;color:#b9cdd5}.tag{font-size:10px;display:inline-block;background:#284a56;border-radius:20px;color:#a3e8dd;padding:7px 10px}
.size{margin:25px 0 18px;padding:18px 0;border-top:1px solid #335664;border-bottom:1px solid #335664;font-size:23px}.size small{display:block;color:#acc5d0;font-size:10px;line-height:1.8;margin-top:7px}
h2{font-size:12px;color:#acc5d0;font-weight:400;margin:22px 0 10px}.views{display:grid;grid-template-columns:1fr 1fr;gap:7px}
button{font:12px Tahoma;background:#214553;color:#e4f2f3;border:1px solid #426674;padding:10px 8px;border-radius:7px;cursor:pointer}button:hover,button.active{background:#117d83;border-color:#5cc0bb}
label{font-size:12px;display:flex;gap:9px;align-items:center;margin:12px 0;color:#d5e8ec}input[type=checkbox]{accent-color:#58c4ba}input[type=range]{width:100%;accent-color:#57c7bb;margin:6px 0}
.note{font-size:11px;line-height:1.8;border-left:2px solid #80d8cb;padding-left:10px;margin-top:23px;color:#b9cdd5}.links{display:grid;gap:8px;margin-top:20px}.links a{font-size:12px;color:#d8f4ee;text-decoration:none}.links a:hover{text-decoration:underline}
main{position:relative;min-width:0;overflow:hidden}canvas{display:block;width:100%;height:100%;touch-action:none}.top{position:absolute;top:24px;left:26px;right:26px;display:flex;justify-content:space-between;gap:12px;pointer-events:none;font-size:12px}.pill{font-size:10px;padding:8px 12px;background:#ffffffe0;border-radius:20px}.help{position:absolute;bottom:23px;left:26px;background:#ffffffe0;padding:10px 14px;border-radius:7px;font-size:11px;pointer-events:none}.rev{position:absolute;bottom:26px;right:24px;font-size:10px;color:#64818e}.status{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);padding:20px;background:white;border-radius:12px;font-size:13px}
@media(max-width:720px){.app{grid-template-columns:1fr;grid-template-rows:57vh 43vh}aside{grid-row:2;padding:20px}main{grid-row:1}.brand,h1,.size,.note{display:none}h2{margin:8px 0}.views{grid-template-columns:repeat(4,1fr)}.links{display:flex;flex-wrap:wrap}.top{left:15px;right:15px;font-size:10px}.help{left:15px;font-size:10px}.rev{display:none}}
</style>
<div class="app"><aside>
<div class="brand">AQUA HATCH / HARDWARE</div><h1>กล่องควบคุม<br><b>CTRL–LV01</b></h1>
<p>ต่อยอดตำแหน่งกล่องจาก McDonald V4<br>สำหรับ ESP32 และโมดูลไฟต่ำ</p><div class="tag">ต้นแบบพิมพ์ 3D · แยกไฟบ้าน</div>
<div class="size">160 × 170 × 65<small>ตัวฐาน / กว้าง × สูง × ลึก / มม.<br>รวมฝาลึก 69 มม. ไม่รวมป้ายและตัวยึด</small></div>
<h2>มุมมอง</h2><div class="views"><button data-view="iso" class="active">สามมิติ</button><button data-view="front">ด้านหน้า</button><button data-view="back">ด้านหลัง</button><button data-view="top">ด้านบน</button></div>
<h2>เปิดตรวจชิ้นส่วน</h2><label><input id="open" type="checkbox">เปิดฝาดูด้านใน</label><label><input id="tray" type="checkbox" checked>แสดงแผ่นยึดบอร์ด</label>
<label for="explode">แยกชิ้นส่วน</label><input id="explode" type="range" min="0" max="100" value="0" aria-label="ระยะแยกชิ้นส่วน">
<button id="reset" style="width:100%;margin-top:8px">คืนมุมมองเริ่มต้น</button>
<div class="note">โมเดลจริงจากไฟล์ CAD แสดงเฉพาะชิ้นพิมพ์ ไม่รวมสกรูและเคเบิลแกลนด์<br><br>พิมพ์ชิ้นทดสอบ 09–11 ก่อน ยังไม่ได้ลองประกอบกับบอร์ดจริง และไม่มีการรับรองกันน้ำ/IP</div>
<div class="links"><a href="README_TH.md">คู่มือพิมพ์และประกอบ</a><a href="preview/05_dimensions.png">ดูผังขนาด</a><a href="AquaHatch_CTRL-LV01_Assembly.step">ไฟล์ CAD ประกอบ STEP</a></div>
</aside><main id="host"><div class="top"><b>กล่องวงจรไฟต่ำ / มองเห็นชิ้นส่วนจริง</b><span class="pill">OFFLINE 3D · หน่วย CAD มม.</span></div><div class="help">ลากเพื่อหมุน · หมุนล้อเพื่อซูม · ใช้สองนิ้วบนจอสัมผัส</div><div class="rev">CTRL–LV01 / 21 OCT 2026</div><div class="status" id="status">กำลังเปิดโมเดล 3D…</div></main></div>
<script type="importmap">__IMPORTS__</script>
<script type="module">
import * as THREE from 'three';import {OrbitControls} from 'orbit';import {GLTFLoader} from 'gltf';
const host=document.querySelector('#host'),status=document.querySelector('#status');
try{
const renderer=new THREE.WebGLRenderer({antialias:true});renderer.setPixelRatio(Math.min(devicePixelRatio,2));renderer.setClearColor(0xe8eff1);renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.15;host.prepend(renderer.domElement);
const scene=new THREE.Scene(),cam=new THREE.PerspectiveCamera(38,1,.001,10);const controls=new OrbitControls(cam,renderer.domElement);controls.enableDamping=true;controls.minDistance=.18;controls.maxDistance=1.6;controls.target.set(0,0,.032);
scene.add(new THREE.HemisphereLight(0xffffff,0x7d959e,2.3));const key=new THREE.DirectionalLight(0xffffff,3.2);key.position.set(.25,.4,.4);scene.add(key);const fill=new THREE.DirectionalLight(0xb9dfe6,1.3);fill.position.set(-.3,.15,-.25);scene.add(fill);
const grid=new THREE.GridHelper(.6,30,0xb9cbd3,0xdce5e8);grid.position.y=-.094;scene.add(grid);
let model;const named={};const open=document.querySelector('#open'),tray=document.querySelector('#tray'),explode=document.querySelector('#explode');
function resize(){cam.aspect=host.clientWidth/host.clientHeight;cam.updateProjectionMatrix();renderer.setSize(host.clientWidth,host.clientHeight)}new ResizeObserver(resize).observe(host);resize();
function frame(){if(!model)return;model.updateMatrixWorld(true);const box=new THREE.Box3();for(const obj of Object.values(named)){if(obj.visible)box.union(new THREE.Box3().setFromObject(obj));}if(box.isEmpty())return;const sphere=box.getBoundingSphere(new THREE.Sphere()),direction=cam.position.clone().sub(controls.target).normalize();const vfov=THREE.MathUtils.degToRad(cam.fov),hfov=2*Math.atan(Math.tan(vfov/2)*cam.aspect);const distance=sphere.radius/Math.sin(Math.min(vfov,hfov)/2)*1.18;controls.target.copy(sphere.center);cam.position.copy(sphere.center).addScaledVector(direction,distance);cam.lookAt(controls.target);controls.update();}
function view(v){controls.target.set(0,0,.032);cam.up.set(0,1,0);if(v==='front')cam.position.set(0,0,.47);else if(v==='back')cam.position.set(0,0,-.47);else if(v==='top'){cam.position.set(0,.47,.032);cam.up.set(0,0,-1)}else cam.position.set(.27,.20,.39);cam.lookAt(controls.target);controls.update();frame();document.querySelectorAll('[data-view]').forEach(b=>b.classList.toggle('active',b.dataset.view===v))}
function update(){if(!model)return;const e=Number(explode.value)/100;for(const[name,obj]of Object.entries(named)){obj.visible=true;obj.position.set(0,0,0);if(name==='lid'||name==='badge'){obj.visible=!open.checked;obj.position.set(e*100,0,e*120)}else if(name==='tray'||name.startsWith('spacer_')){obj.visible=tray.checked;obj.position.set(e*45,0,e*80)}else if(name==='cable_panel')obj.position.y=-e*50;else if(name.startsWith('mount_'))obj.position.z=-e*25;}frame(); }
document.querySelectorAll('[data-view]').forEach(b=>b.onclick=()=>view(b.dataset.view));open.onchange=()=>{explode.value=0;update()};tray.onchange=update;explode.oninput=()=>{open.checked=false;update()};document.querySelector('#reset').onclick=()=>{open.checked=false;tray.checked=true;explode.value=0;update();view('iso')};
const bytes=Uint8Array.from(atob('__GLB__'),c=>c.charCodeAt(0));new GLTFLoader().parse(bytes.buffer,'',g=>{model=g.scene;scene.add(model);for(const name of ['body','lid','tray','cable_panel','mount_top','mount_bottom','badge','spacer_1','spacer_2','spacer_3','spacer_4']){const obj=model.getObjectByName(name);if(obj)named[name]=obj;}model.traverse(o=>{if(o.isMesh){const list=Array.isArray(o.material)?o.material:[o.material];for(const m of list){m.roughness=.48;m.metalness=.04;}}});update();view('iso');status.remove();document.title='AquaHatch CTRL–LV01 | โมเดลพร้อมดู';},err=>{status.textContent='เปิดโมเดลไม่ได้: '+err.message;});
renderer.setAnimationLoop(()=>{controls.update();renderer.render(scene,cam)});
}catch(err){status.textContent='เปิด WebGL ไม่สำเร็จ: '+err.message;}
</script></html>'''
html=template.replace('__IMPORTS__',json.dumps({'imports':imports})).replace('__GLB__',glb)
(OUT/'Model_Viewer.html').write_text(html,encoding='utf-8')
license_path=DEPS/'LICENSE.txt'
shutil.copyfile(license_path,OUT/'THREE_LICENSE.txt')
print('Offline viewer built:',len(html),'characters')
