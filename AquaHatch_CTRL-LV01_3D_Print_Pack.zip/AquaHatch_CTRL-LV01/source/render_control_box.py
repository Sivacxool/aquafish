"""Render the exact exported CAD meshes in Blender; STL coordinates are mm.
Run: blender --background --python outputs/source/render_control_box.py
"""
from pathlib import Path
import bpy
import json
import math
from mathutils import Vector, Matrix

OUT=Path(__file__).resolve().parent.parent
ROOT=OUT.parent
MESH=OUT/'_build/assembly_meshes'
P=json.loads((OUT/'source/parameters.json').read_text(encoding='utf-8'))
bpy.ops.wm.read_factory_settings(use_empty=True)


def mat(name,color,metal=0,rough=.42):
    m=bpy.data.materials.new(name)
    linear=tuple(c/12.92 if c<=.04045 else ((c+.055)/1.055)**2.4 for c in color)
    m.diffuse_color=(*linear,1)
    m.use_nodes=True
    bs=m.node_tree.nodes.get('Principled BSDF')
    bs.inputs['Base Color'].default_value=(*linear,1)
    bs.inputs['Metallic'].default_value=metal
    bs.inputs['Roughness'].default_value=rough
    return m


navy=mat('PETG / deep navy',(.045,.11,.145),.05,.35)
white=mat('PETG / warm white',(.85,.90,.89),.02,.36)
teal=mat('PETG / teal',(.025,.43,.43),.04,.37)
traymat=mat('PETG / pale teal',(.28,.57,.57),.04,.42)
black=mat('Purchased hardware / black',(.028,.038,.043),.05,.4)
metal=mat('Purchased fasteners',(.30,.36,.38),.72,.27)
floor_mat=mat('Studio backdrop',(.72,.78,.79),0,.65)


def camera_at(location,target,scale=0.31):
    scene=bpy.context.scene
    if not scene.camera:
        d=bpy.data.cameras.new('Presentation camera')
        scene.camera=bpy.data.objects.new('Presentation camera',d)
        scene.collection.objects.link(scene.camera)
    cam=scene.camera
    cam.location=location
    cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler()
    cam.data.type='ORTHO'
    cam.data.ortho_scale=scale
    cam.data.lens=60


def cyl(name,d,h,loc,material,direction=(0,0,1),vertices=64):
    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices,radius=d/2,depth=h,location=loc)
    obj=bpy.context.object
    obj.name=name
    obj.rotation_euler=Vector(direction).to_track_quat('Z','Y').to_euler()
    obj.data.materials.append(material)
    bevel=obj.modifiers.new('Soft hardware edges','BEVEL')
    bevel.width=.0005;bevel.segments=3
    for face in obj.data.polygons:face.use_smooth=True
    obj['purchased_hardware_visual_only']=True
    return obj


def area(name,loc,power,size):
    light=bpy.data.lights.new(name,'AREA')
    obj=bpy.data.objects.new(name,light);bpy.context.scene.collection.objects.link(obj)
    obj.location=loc;light.energy=power;light.shape='DISK';light.size=size
    obj.rotation_euler=(-obj.location).to_track_quat('-Z','Y').to_euler()


assembly={}
for path in sorted(MESH.glob('*.stl')):
    bpy.ops.wm.stl_import(filepath=str(path),global_scale=.001)
    obj=bpy.context.object
    obj.name=path.stem
    obj.data.materials.clear()
    obj.data.materials.append(white if path.stem=='lid' else teal if path.stem=='badge' else traymat if path.stem=='tray' else navy)
    if path.stem=='badge':
        obj.data.materials.append(white)
        for poly in obj.data.polygons:
            if sum(obj.data.vertices[i].co.z for i in poly.vertices)/len(poly.vertices)>70.501:
                poly.material_index=1
    obj.rotation_euler.x=math.pi/2
    obj['printed_part']=True
    obj['cad_source_mm']=path.name
    assembly[path.stem]=obj

hardware=[]
for x in [-.069,.069]:
    for y in [-.074,.074]:
        hardware.append(cyl('M3 lid washer',.007,.0006,(x,-.0693,y),metal,(0,-1,0)))
        hardware.append(cyl('M3 lid screw head',.0056,.0024,(x,-.0708,y),black,(0,-1,0)))
for x in [-.048,-.016,.016,.048]:
    hardware.append(cyl('M16 gland nut / illustrative',.022,.0035,(x,-.0365,-.090),black,vertices=6))
    hardware.append(cyl('M16 gland barrel / illustrative',.019,.010,(x,-.0365,-.096),black))
    hardware.append(cyl('M16 gland cap / illustrative',.018,.006,(x,-.0365,-.104),black))
    hardware.append(cyl('DC cable / illustrative',.005,.018,(x,-.0365,-.115),black))

scene=bpy.context.scene
scene.unit_settings.system='METRIC'
scene.unit_settings.length_unit='MILLIMETERS'
scene.render.engine='CYCLES'
scene.cycles.samples=48
scene.cycles.use_denoising=True
try:
    prefs=bpy.context.preferences.addons['cycles'].preferences
    prefs.compute_device_type='CUDA'
    prefs.get_devices()
    gpu=False
    for device in prefs.devices:
        device.use=device.type=='CUDA'
        gpu=gpu or device.use
    if gpu:scene.cycles.device='GPU'
except Exception:
    pass
scene.render.resolution_x=1500
scene.render.resolution_y=1200
scene.render.resolution_percentage=100
if not scene.world:
    scene.world=bpy.data.worlds.new('Studio world')
scene.world.color=(.5,.5,.5)
scene.world.use_nodes=True
scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.78,.85,.88,1)
scene.world.node_tree.nodes['Background'].inputs[1].default_value=.5
scene.view_settings.view_transform='AgX'
area('Large softbox',(.20,-.30,.42),12,.35)
area('Fill light',(-.35,-.10,.25),7,.30)
area('Rear rim',(.14,.26,.30),10,.25)
bpy.ops.mesh.primitive_plane_add(size=2,location=(0,0,-.126))
ground=bpy.context.object;ground.name='Studio / not a printed part';ground.data.materials.append(floor_mat)


def render(name):
    scene.render.filepath=str(OUT/'preview'/name)
    bpy.ops.render.render(write_still=True)
    print('RENDERED',name,flush=True)


camera_at((.27,-.42,.24),(0,-.025,-.008),.305)
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'AquaHatch_CTRL-LV01.blend'))
render('01_closed.png')
for name in ['lid','badge']:
    assembly[name].hide_render=True
for obj in hardware:obj.hide_render=True
camera_at((.23,-.46,.31),(0,-.015,0),.29)
render('02_open.png')

# Exploded placement is for explanation, not an alternative print orientation.
for obj in assembly.values():obj.hide_render=False
for obj in hardware:obj.hide_render=True
for name,obj in assembly.items():
    if name in ['lid','badge']:
        obj.location+=Vector((.17,-.08,.025))
    elif name=='tray' or name.startswith('spacer_'):
        obj.location+=Vector((.075,-.045,.012))
    elif name=='cable_panel':
        obj.location+=Vector((0,0,-.055))
camera_at((.38,-.61,.35),(.065,-.055,-.015),.52)
ground.location.z=-.23
render('03_exploded.png')

# A new copy of the previous model is used only to illustrate the chosen location.
old=Path('C:/Users/godis/Documents/Codex/2026-09-10/new-chat-2/outputs/catfish_mcdonald_v4/McDonald_V4_Thai.blend')
if old.exists():
    bpy.ops.wm.open_mainfile(filepath=str(old))
    for obj in list(bpy.data.objects):
        if obj.name.startswith('CONTROL__'):
            obj.hide_render=True
    matrix=Matrix(((0,0,1,0),(1,0,0,0),(0,1,0,0),(0,0,0,1)))
    matrix.translation=Vector((.470,.190,1.195))
    for path in sorted(MESH.glob('*.stl')):
        bpy.ops.wm.stl_import(filepath=str(path),global_scale=.001)
        obj=bpy.context.object;obj.name='CTRL_LV01__'+path.stem
        obj.matrix_world=matrix @ Matrix.Scale(.001,4)
        obj.data.materials.clear()
        # Recreate materials after loading another .blend.
        color=(.85,.90,.89) if path.stem=='lid' else (.025,.43,.43) if path.stem=='badge' else (.045,.11,.145)
        obj.data.materials.append(mat('New LV / '+path.stem,color,.03,.42))
    scene=bpy.context.scene
    scene.render.resolution_x=1500;scene.render.resolution_y=1200;scene.render.resolution_percentage=100
    scene.cycles.samples=32
    scene.cycles.use_denoising=True
    scene.render.filepath=str(OUT/'preview'/'04_v4_location_reference.png')
    bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'AquaHatch_CTRL-LV01_V4_Location.blend'))
    bpy.ops.render.render(write_still=True)
    print('RENDERED V4 location reference (original file left unchanged).',flush=True)
