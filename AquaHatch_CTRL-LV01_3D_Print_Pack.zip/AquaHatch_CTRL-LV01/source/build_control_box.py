"""Parametric millimetre CAD. Run with Python 3.12 + cadquery 2.8.0, trimesh.

STL/3MF exports are independent parts placed flat on Z=0 for printing.
STEP/GLB assembly uses X=width, Y=up in service, Z=outward from back.
No hardware, electronics or wet/electrical protection certification is implied.
"""
from pathlib import Path
import itertools
import json
import math
import struct
import cadquery as cq
import trimesh

HERE=Path(__file__).resolve().parent
OUT=HERE.parent
P=json.loads((HERE/'parameters.json').read_text(encoding='utf-8'))
for folder in ['STL','3MF','STEP','preview']:
    (OUT/folder).mkdir(exist_ok=True)
(OUT/'_build'/'assembly_meshes').mkdir(parents=True,exist_ok=True)
W,H,D=P['width'],P['height'],P['body_depth']
t,b=P['wall'],P['back']
r=P['corner_radius']
clearance=P['fit_clearance_per_side']
M3=P['m3_hole']
lid_xy=[(x,y) for x in [-W/2+11,W/2-11] for y in [-H/2+11,H/2-11]]
tray_xy=[(x,y) for x in [-56,56] for y in [-56,56]]
mount_xy=[(x,y) for x in [-46,46] for y in [-64,64]]


def wp(shape):
    return shape if isinstance(shape,cq.Workplane) else cq.Workplane('XY').newObject([shape])


def rounded(w,h,depth,radius=0,z=0,x=0,y=0):
    item=cq.Workplane('XY').box(w,h,depth,centered=(True,True,False))
    if radius:
        item=item.edges('|Z').fillet(radius)
    return item.translate((x,y,z))


def cyl(d,depth,x=0,y=0,z=0):
    return cq.Workplane('XY').center(x,y).circle(d/2).extrude(depth).translate((0,0,z))


def hole_y(d,length,x,y,z):
    return wp(cq.Solid.makeCylinder(d/2,length,cq.Vector(x,y,z),cq.Vector(0,1,0)))


def hex_z(af,depth,x,y,z):
    return cq.Workplane('XY').center(x,y).polygon(6,af/math.cos(math.pi/6)).extrude(depth).translate((0,0,z))


def hex_y(af,depth,x,y,z):
    # XZ normal is -Y; the nut is loaded from the open interior side.
    return cq.Workplane('XZ').polygon(6,af/math.cos(math.pi/6)).extrude(depth).translate((x,y,z))


def lid_shape(width,height,depth,outer_r,corner_posts=()):
    plate=rounded(width,height,P['lid_thickness'],outer_r)
    lw=width-2*t-2*clearance
    lh=height-2*t-2*clearance
    lr=max(.8,outer_r-t-clearance)
    lip=rounded(lw,lh,P['lip_depth'],lr,z=P['lid_thickness'])
    lip=lip.cut(rounded(lw-2*P['lip_wall'],lh-2*P['lip_wall'],P['lip_depth']+2,max(.3,lr-P['lip_wall']),z=P['lid_thickness']-1))
    for x,y in corner_posts:
        lip=lip.cut(rounded(25,25,P['lip_depth']+2,0,z=P['lid_thickness']-1,x=x,y=y))
        plate=plate.cut(cyl(M3,P['lid_thickness']+2,x,y,-1))
    return plate.union(lip)


# Body opens upward in printing: no lid, roof or long horizontal bridge.
body=rounded(W,H,D,r)
body=body.cut(rounded(W-2*t,H-2*t,D+1,r-t,z=b))
for x,y in lid_xy:
    body=body.union(cyl(12,D-b,x,y,b))
    # Each tall boss is tied into the adjacent side wall, not a free cantilever.
    side=1 if x>0 else -1
    body=body.union(rounded(12,8,D-b,0,x=side*(W/2-6),y=y,z=b))
    body=body.cut(cyl(M3,9,x,y,D-9))
    body=body.cut(hex_z(P['m3_nut_af'],P['m3_nut_depth']+.1,x,y,D-P['m3_nut_depth']))
for x,y in tray_xy:
    body=body.union(cyl(10,P['tray_bottom']-b,x,y,b))
    body=body.cut(cyl(M3,6,x,y,P['tray_bottom']-6))
    body=body.cut(hex_z(P['m3_nut_af'],P['m3_nut_depth']+.1,x,y,P['tray_bottom']-P['m3_nut_depth']))
for x,y in mount_xy:
    body=body.cut(cyl(P['m4_hole'],b+2,x,y,-1))

# Full-height side columns around an open-topped cable-panel notch.
# This avoids an unsupported 128 mm lintel while the body is printed back-down.
for x in [-70,70]:
    body=body.union(rounded(12,12,53,0,x=x,y=-H/2+6,z=b))
body=body.cut(rounded(P['cable_opening_width'],18,D+2-P['cable_opening_back_z'],0,y=-H/2,z=P['cable_opening_back_z']))
for x in [-70,70]:
    for z in [22,48]:
        body=body.cut(hole_y(M3,18,x,-H/2-5,z))
        body=body.cut(hex_y(P['m3_nut_af'],P['m3_nut_depth'],x,-H/2+12,z))

lid=lid_shape(W,H,D,r,lid_xy)
tray=rounded(P['tray_width'],P['tray_height'],P['tray_thickness'],4)
for x,y in tray_xy:
    tray=tray.cut(cyl(M3,5,x,y,-1))
for x in P['slot_columns']:
    for y in P['slot_rows']:
        slot=cq.Workplane('XY').center(x,y).slot2D(P['slot_length'],M3,90).extrude(5).translate((0,0,-1))
        tray=tray.cut(slot)


def cable_panel(drilled):
    panel=rounded(P['cable_panel_width'],P['cable_panel_height'],P['cable_panel_thickness'],3)
    tongue=rounded(P['cable_opening_width']-2*clearance,54.2,2.7,1.5,z=3,y=-1)
    panel=panel.union(tongue)
    for x in [-70,70]:
        for y in [14.5,-11.5]:
            panel=panel.cut(cyl(M3,8,x,y,-1))
    for x in P['gland_x']:
        if drilled:
            panel=panel.cut(cyl(P['gland_hole'],8,x,0,-1))
            # Recess keeps gland clamping thickness at 3 mm, not 5.7 mm.
            panel=panel.cut(cyl(P['gland_nut_recess'],4,x,0,3))
        else:
            # Blind center marks only; blank variant has no wire bores.
            panel=panel.cut(cyl(1.2,.6,x,0,5.1))
    return panel


blank_panel=cable_panel(False)
port_panel=cable_panel(True)
spacer=cyl(8,6).cut(cyl(M3,8,z=-1))
mount_bar=rounded(P['mount_bar_width'],P['mount_bar_height'],P['mount_bar_thickness'],3)
for x in [-46,46]:
    mount_bar=mount_bar.cut(cyl(P['m4_hole'],7,x,0,-1))
    mount_bar=mount_bar.cut(hex_z(7.4,3.5,x,0,1.5))
for x in [-65,65]:
    slot=cq.Workplane('XY').center(x,0).slot2D(12,5,90).extrude(7).translate((0,0,-1))
    mount_bar=mount_bar.cut(slot)

badge=rounded(104,23,1.4,3)
letters=cq.Workplane('XY').text('AQUA HATCH',8,.4,font='Arial',kind='bold',combine=True).translate((0,0,1.4))
badge=badge.union(letters)
gauge=rounded(78,34,6,3)
for x,d,af in zip([-25,0,25],[3.2,3.4,3.6],[5.8,6.0,6.2]):
    gauge=gauge.cut(cyl(d,8,x,8,-1))
    gauge=gauge.cut(hex_z(af,2.8,x,-8,3.2))
    gauge=gauge.cut(cyl(M3,8,x,-8,-1))
rim_base=rounded(45,35,12,5).cut(rounded(45-2*t,35-2*t,14,5-t,z=b))
rim_lid=lid_shape(45,35,12,5)

parts={
 '01_body':body,'02_lid':lid,'03_universal_tray':tray,
 '04_cable_panel_blank':blank_panel,'05_cable_panel_4x16p2':port_panel,
 '06_pcb_spacer':spacer,'07_mount_bar':mount_bar,'08_badge':badge,
 '09_hole_nut_gauge':gauge,'10_rim_test_base':rim_base,'11_rim_test_lid':rim_lid,
}
meta={
 '01_body':('ฐานกล่อง',1,'ด้านหลังราบกับฐานพิมพ์ ช่องเปิดหงายขึ้น'),
 '02_lid':('ฝาหน้า',1,'ผิวหน้านอกราบกับฐานพิมพ์ ขอบสวมอยู่ด้านบน'),
 '03_universal_tray':('แผ่นยึดบอร์ดปรับตำแหน่ง',1,'วางแบน'),
 '04_cable_panel_blank':('แผงสายแบบยังไม่เจาะ',1,'เลือกแทนชิ้น 05 เมื่อยังไม่ทราบเคเบิลแกลนด์'),
 '05_cable_panel_4x16p2':('แผงสาย 4 รู 16.2 มม.',1,'เลือกแทนชิ้น 04 วางด้านนอกราบ ขอบสวมขึ้น'),
 '06_pcb_spacer':('เสารอง PCB',4,'พิมพ์เพิ่มตามตำแหน่งจริง ไม่ยืนยันรูบอร์ดรุ่นใด'),
 '07_mount_bar':('แถบยึดหลัง',2,'หน้าราบลง ช่องน็อตขึ้น'),
 '08_badge':('ป้ายหน้า',1,'หลังป้ายราบกับฐานพิมพ์'),
 '09_hole_nut_gauge':('ชิ้นทดสอบรูและน็อต',1,'พิมพ์ทดสอบก่อนตัวจริง'),
 '10_rim_test_base':('ชิ้นทดสอบขอบฐาน',1,'หงายช่องเปิด'),
 '11_rim_test_lid':('ชิ้นทดสอบขอบฝา',1,'ผิวด้านนอกราบ'),
}

assembled={
 'body':body,
 'lid':lid.rotate((0,0,0),(0,1,0),180).translate((0,0,D+P['lid_thickness'])),
 'tray':tray.translate((0,0,P['tray_bottom'])),
 'cable_panel':port_panel.rotate((0,0,0),(1,0,0),-90).translate((0,-H/2-3,P['cable_panel_z_center'])),
 'mount_top':mount_bar.rotate((0,0,0),(0,1,0),180).translate((0,64,0)),
 'mount_bottom':mount_bar.rotate((0,0,0),(0,1,0),180).translate((0,-64,0)),
 'badge':badge.translate((0,40,D+P['lid_thickness']+.1)),
}
for i,(x,y) in enumerate([(-50,15),(-10,15),(-50,45),(-10,45)]):
    assembled[f'spacer_{i+1}']=spacer.translate((x,y,P['tray_bottom']+P['tray_thickness']))

colors={'body':(.09,.20,.25),'lid':(.91,.94,.93),'tray':(.42,.69,.69),'cable_panel':(.08,.16,.20),'mount_top':(.12,.24,.28),'mount_bottom':(.12,.24,.28),'badge':(.02,.49,.50)}
checks={'revision':P['revision'],'units':'mm','parts':{},'assembly_intersections':{},'limits':[]}
for name,part in parts.items():
    solid=part.val()
    assert solid.isValid(),f'Invalid CAD: {name}'
    assert len(part.solids().vals())==1,f'Not one connected solid: {name}'
    cq.exporters.export(part,str(OUT/'STL'/f'{name}.stl'),tolerance=.025,angularTolerance=.12)
    cq.exporters.export(part,str(OUT/'3MF'/f'{name}.3mf'),tolerance=.025,angularTolerance=.12)
    cq.exporters.export(part,str(OUT/'STEP'/f'{name}.step'))
    mesh=trimesh.load_mesh(OUT/'STL'/f'{name}.stl',process=True)
    assert mesh.is_watertight,f'Open mesh: {name}'
    assert mesh.is_winding_consistent,f'Bad normals: {name}'
    assert mesh.volume>0,f'Nonpositive volume: {name}'
    assert len(mesh.split())==1,f'Disconnected mesh: {name}'
    assert abs(mesh.bounds[0,2])<1e-4,f'Not on print bed: {name}'
    assert all(mesh.extents[i]<=P['maximum_part_xy'][i] for i in [0,1]),name
    checks['parts'][name]={
      'name_th':meta[name][0],'quantity':meta[name][1],'print_note':meta[name][2],
      'cad_valid':True,'solid_count':1,'watertight':True,'normals_consistent':True,
      'bounds_mm':mesh.bounds.round(4).tolist(),'size_mm':mesh.extents.round(4).tolist(),
      'solid_volume_mm3':round(solid.Volume(),2),'stl_volume_mm3':round(float(mesh.volume),2),
      'triangles':len(mesh.faces),
    }
    print('EXPORTED',name,mesh.extents.round(2),flush=True)

for (an,a),(bn,bb) in itertools.combinations(assembled.items(),2):
    vol=a.intersect(bb).val().Volume()
    checks['assembly_intersections'][an+' / '+bn]=round(vol,6)
    assert vol<.01,f'Assembly collision {an}/{bn}: {vol:.5f} mm3'

assembly=cq.Assembly(name='AquaHatch_CTRL_LV01')
for name,shape in assembled.items():
    assembly.add(shape,name=name,color=cq.Color(*colors.get(name,(.10,.28,.31))))
    cq.exporters.export(shape,str(OUT/'_build'/'assembly_meshes'/f'{name}.stl'),tolerance=.025,angularTolerance=.12)
assembly.export(str(OUT/'AquaHatch_CTRL-LV01_Assembly.step'))
glb_path=OUT/'preview'/'AquaHatch_CTRL-LV01.glb'
assembly.export(str(glb_path),tolerance=.025,angularTolerance=.12)
# OCCT writes raw millimetres and a Z-up correction. This design already uses
# Y as service-up. Normalize the scene root to glTF's metres and Y-up convention.
raw=glb_path.read_bytes()
json_size=struct.unpack_from('<I',raw,12)[0]
document=json.loads(raw[20:20+json_size])
root_node=document['nodes'][document['scenes'][0]['nodes'][0]]
root_node['rotation']=[0,0,0,1]
root_node['scale']=[.001,.001,.001]
document['asset']['extras']={'source_units':'mm','display_units':'m','service_up':'+Y'}
encoded=json.dumps(document,separators=(',',':')).encode()
encoded+=b' '*((-len(encoded))%4)
remaining=raw[20+json_size:]
glb_path.write_bytes(struct.pack('<III',0x46546C67,2,20+len(encoded)+len(remaining))+struct.pack('<II',len(encoded),0x4E4F534A)+encoded+remaining)
checks['limits']=[
 'Only CAD geometry and mesh checks; no physical printing, board-fit, thermal, structural, water-ingress or electrical certification.',
 'Exact ESP32/module sizes and printer model are not yet supplied; tray is universal with tie/bolt slots, not an exact board drilling template.',
 'External 220 V heater/relay contacts, mains AC adapter and high-current load wiring are excluded.',
 'Gland holes are 16.2 mm design values. Confirm actual gland thread, washer and nut fit before choosing drilled panel.',
 'V4 control cabinet was a vendor/component envelope. New LV enclosure is smaller and is not a drop-in industrial cabinet or rated emergency-stop enclosure.',
]
(OUT/'geometry_checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf-8')
(OUT/'preview'/'assembly_parts.json').write_text(json.dumps({name:{'color':colors.get(name,(.10,.28,.31))} for name in assembled},indent=2),encoding='utf-8')
print('CAD, mesh and assembly interference checks passed.',flush=True)
