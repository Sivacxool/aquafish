"""Re-open exported STEP/3MF/STL files and check units, scale and volumes."""
from pathlib import Path
import json
import zipfile
import xml.etree.ElementTree as ET
import cadquery as cq
import numpy as np
import trimesh

OUT = Path(__file__).resolve().parent.parent
geometry = json.loads((OUT / 'geometry_checks.json').read_text(encoding='utf-8'))
results = {}
for stem, expected in geometry['parts'].items():
    solid = cq.importers.importStep(str(OUT / 'STEP' / (stem + '.step'))).val()
    assert solid.isValid() and len(solid.Solids()) == 1, stem
    assert abs(solid.Volume() - expected['solid_volume_mm3']) < .02, stem
    stl = trimesh.load_mesh(OUT / 'STL' / (stem + '.stl'))
    with zipfile.ZipFile(OUT / '3MF' / (stem + '.3mf')) as z:
        doc = ET.fromstring(z.read('3D/3dmodel.model'))
        unit = doc.get('unit', 'millimeter')
    assert unit == 'millimeter', (stem, unit)
    mesh3mf = trimesh.load(OUT / '3MF' / (stem + '.3mf'), force='mesh')
    delta = float(np.max(np.abs(mesh3mf.bounds - stl.bounds)))
    assert delta < .01, (stem, delta)
    results[stem] = {'step_valid': True, 'step_solids': 1,
                     'step_volume_mm3': round(solid.Volume(), 4),
                     'three_mf_unit': unit,
                     'max_3mf_stl_bounds_difference_mm': round(delta, 6)}

assembly = cq.importers.importStep(str(OUT / 'AquaHatch_CTRL-LV01_Assembly.step')).val()
assert assembly.isValid() and len(assembly.Solids()) == 11
glb = trimesh.load(OUT / 'preview/AquaHatch_CTRL-LV01.glb', force='mesh')
assert np.max(glb.extents) < .3, glb.extents
report = {'parts': results, 'assembly_step_valid': True,
          'assembly_step_solids': len(assembly.Solids()),
          'glb_extents_metres': glb.extents.tolist()}
(OUT / 'export_roundtrip_checks.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print('PASS:', len(results), 'STEP and 3MF/STL round trips; assembly 11 solids; GLB scale', glb.extents)
