"""Dimensioned drawings from the same parameters. Not a 1:1 drill template."""
from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Circle, Polygon, Rectangle
from matplotlib.font_manager import FontProperties
import numpy as np

OUT=Path(__file__).resolve().parent.parent
P=json.loads((OUT/'source/parameters.json').read_text(encoding='utf-8'))
font=FontProperties(fname='C:/Windows/Fonts/tahoma.ttf')
plt.rcParams.update({'font.family':font.get_name(),'font.size':10,'axes.edgecolor':'#c7d6dc','text.color':'#153d4d','svg.fonttype':'path'})
NAVY,TEAL,GRAY='#143f50','#087d86','#607985'

def rounded(ax,x,y,w,h,r=5,fc='#eaf2f3',ec=NAVY,lw=1.2):
    ax.add_patch(FancyBboxPatch((x-w/2,y-h/2),w,h,boxstyle=f'round,pad=0,rounding_size={r}',facecolor=fc,edgecolor=ec,linewidth=lw))

def dimx(ax,x1,x2,y,label):
    ax.annotate('',(x1,y),(x2,y),arrowprops={'arrowstyle':'<->','color':TEAL,'lw':.9})
    ax.text((x1+x2)/2,y+2,label,ha='center',va='bottom',color=TEAL)

def dimy(ax,y1,y2,x,label):
    ax.annotate('',(x,y1),(x,y2),arrowprops={'arrowstyle':'<->','color':TEAL,'lw':.9})
    ax.text(x-2,(y1+y2)/2,label,ha='right',va='center',rotation=90,color=TEAL)

def setup(ax,title,xlim,ylim):
    ax.set_aspect('equal');ax.set_xlim(*xlim);ax.set_ylim(*ylim);ax.axis('off')
    ax.set_title(title,fontproperties=font,fontsize=12,fontweight='bold',loc='left',pad=13)

fig,axs=plt.subplots(2,2,figsize=(14,13.5),facecolor='white')
fig.subplots_adjust(left=.055,right=.97,top=.88,bottom=.12,wspace=.24,hspace=.3)
fig.text(.055,.963,'AQUA HATCH',fontsize=27,fontweight='bold',color=NAVY)
fig.text(.055,.928,'CTRL–LV01  |  กล่องวงจรไฟต่ำสำหรับ ESP32',fontproperties=font,fontsize=16)
fig.text(.97,.95,'ขนาดทั้งหมดเป็นมิลลิเมตร\nแบบต้นแบบ · 21 ตุลาคม 2026',fontproperties=font,fontsize=10,ha='right',color=GRAY)

ax=axs[0,0];setup(ax,'01 / ฝาหน้าและตำแหน่งสกรู',(-105,100),(-109,105))
rounded(ax,0,0,P['width'],P['height'],8,fc='#f2f6f6')
for x in [-69,69]:
    for y in [-74,74]:ax.add_patch(Circle((x,y),P['m3_hole']/2,fc='white',ec=NAVY,lw=.8))
rounded(ax,0,40,104,23,3,fc=TEAL,ec=TEAL)
ax.text(0,40,'AQUA HATCH',ha='center',va='center',fontsize=9,color='white',weight='bold')
ax.text(0,-8,'ฝาทึบ ไม่มีรูจอที่ยังไม่ทราบรุ่น',ha='center',fontproperties=font,fontsize=9,color=GRAY)
ax.text(0,-27,'4 × รู 3.4 / ระยะศูนย์ 138 × 148',ha='center',fontproperties=font,fontsize=9,color=GRAY)
dimx(ax,-80,80,-98,'160');dimy(ax,-85,85,-94,'170')

ax=axs[0,1];setup(ax,'02 / รูปตัดข้างและลำดับชั้น',(-22,94),(-103,105))
ax.add_patch(Rectangle((0,-85),65,170,fc='#eaf2f3',ec=NAVY,lw=1.1))
ax.add_patch(Rectangle((3,-82),62,164,fc='white',ec='none'))
ax.add_patch(Rectangle((65,-85),4,170,fc='#eaf2f3',ec=NAVY,lw=1.1))
ax.add_patch(Rectangle((11,-67),3,134,fc='#80b8b7',ec=TEAL))
ax.add_patch(Rectangle((-5,54),5,20,fc='#6a8791',ec=NAVY))
ax.add_patch(Rectangle((-5,-74),5,20,fc='#6a8791',ec=NAVY))
ax.text(18,12,'พื้นที่ติดตั้งบอร์ด\nและเดินสาย',fontproperties=font,fontsize=10,ha='left',va='center')
ax.annotate('หลัง 3',xy=(1.5,0),xytext=(-17,14),fontproperties=font,fontsize=9,arrowprops={'arrowstyle':'-','color':GRAY},rotation=90)
ax.text(13,-76,'ถาด 3 / ใต้ถาด 8',fontproperties=font,fontsize=8,ha='left',color=TEAL)
dimx(ax,0,65,-98,'ฐานลึก 65')
dimx(ax,0,69,96,'รวมฝา 69')
ax.text(35,-111,'ไม่รวมสกรู ป้าย และแถบยึดหลัง',fontproperties=font,fontsize=8,ha='center',color=GRAY)

ax=axs[1,0];setup(ax,'03 / แผ่นยึดบอร์ดแบบเลื่อนตำแหน่ง',(-89,90),(-91,89))
rounded(ax,0,0,132,134,4,fc='#d9eeee')
for x in [-56,56]:
    for y in [-56,56]:ax.add_patch(Circle((x,y),1.7,fc='white',ec=NAVY,lw=.7))
for x in P['slot_columns']:
    for y in P['slot_rows']:rounded(ax,x,y,3.4,20,1.7,fc='white',ec=NAVY,lw=.6)
dimx(ax,-66,66,-80,'132');dimy(ax,-67,67,-79,'134')
ax.text(0,78,'24 ร่อง 3.4 × 20 / ระยะศูนย์ยึดถาด 112 × 112',fontproperties=font,fontsize=8,ha='center',color=GRAY)

ax=axs[1,1];setup(ax,'04 / แผงสายแบบเจาะรู (มีแบบแผงทึบให้เลือก)',(-95,95),(-58,58))
rounded(ax,0,0,150,57,3,fc='#eaf2f3')
for x in P['gland_x']:
    ax.add_patch(Circle((x,0),8.1,fc='white',ec=NAVY,lw=1.0))
    ax.add_patch(Circle((x,0),13,fc='none',ec=GRAY,lw=.7,ls='--'))
for x in [-70,70]:
    for y in [14.5,-11.5]:ax.add_patch(Circle((x,y),1.7,fc='white',ec=NAVY,lw=.7))
dimx(ax,-75,75,-41,'150');dimy(ax,-28.5,28.5,-86,'57')
ax.text(0,40,'4 × Ø16.2 / ศูนย์รูห่าง 32 / หลังแผงบ่า Ø26',fontproperties=font,fontsize=8,ha='center',color=GRAY)
ax.text(0,-53,'ตรวจขนาดเกลียวและน็อตแกลนด์จริงก่อนเลือกแผงเจาะ',fontproperties=font,fontsize=8,ha='center',color=TEAL)

fig.text(.055,.067,'ผนัง/หลัง 3 มม.  •  ฝา 4 มม.  •  ระยะสวม 0.4 มม./ด้าน  •  ไม่ใช่เทมเพลตเจาะ 1:1',fontproperties=font,fontsize=10,color=NAVY)
fig.text(.055,.039,'ใช้ไฟล์ CAD/STL เป็นขนาดอ้างอิง พิมพ์ชิ้นทดสอบ 09–11 ก่อน  |  ไฟต่ำเท่านั้น ไม่มีการรับรอง IP/กันน้ำ',fontproperties=font,fontsize=10,color=TEAL)
fig.savefig(OUT/'preview'/'05_dimensions.png',dpi=160,facecolor='white')
fig.savefig(OUT/'Dimensions_CTRL-LV01.svg',facecolor='white')
plt.close(fig)

# Printable component footprints are illustrative envelopes, not PCB hole templates.
fig,ax=plt.subplots(figsize=(10,11),facecolor='white')
setup(ax,'ตัวอย่างจัดวางภายใน — ต้องวัดบอร์ดจริงก่อนยึด',(-90,90),(-95,100))
rounded(ax,0,0,154,164,5,fc='#f2f7f7')
rounded(ax,0,0,132,134,4,fc='#d8ebeb')
for x in P['slot_columns']:
    for y in P['slot_rows']:rounded(ax,x,y,3.4,20,1.7,fc='white',ec='#9ebcbf',lw=.4)
for x,y,w,h,label in [(-30,30,60,45,'ESP32\n60 × 45'),(33,30,45,30,'โมดูล DC\n45 × 30'),(-35,-17,38,20,'โมดูล DC\n38 × 20'),(0,-50,110,18,'พื้นที่พักสาย / จุดต่อไฟต่ำ')]:
    rounded(ax,x,y,w,h,2,fc='#ffffffda',ec=TEAL)
    ax.text(x,y,label,fontproperties=font,ha='center',va='center',fontsize=11,color=NAVY)
ax.text(0,87,'ส่วนบน: จัดเสาอากาศตามคู่มือบอร์ด หลีกเลี่ยงโลหะบัง',fontproperties=font,fontsize=10,ha='center',color=TEAL)
for x in P['gland_x']:ax.add_patch(Circle((x,-85),5,fc='#234e60',ec='none'))
fig.text(.09,.045,'ขนาดบล็อกเป็นการเผื่อพื้นที่ ไม่ยืนยันรุ่น ESP32/MOSFET/โมดูลจริง และไม่ใช่ผังเดินสาย',fontproperties=font,fontsize=10,color=TEAL)
fig.savefig(OUT/'preview'/'06_layout_reference.png',dpi=150,facecolor='white')
plt.close(fig)
print('Dimension and illustrative layout drawings generated.')
