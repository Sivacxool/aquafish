@echo off
chcp 65001 >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\Install-FirstBoot.ps1" -Kind wroom-da -ReadOnly
pause
