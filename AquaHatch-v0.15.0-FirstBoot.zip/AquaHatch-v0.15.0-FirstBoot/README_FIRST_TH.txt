﻿AquaHatch 0.15.0 สำหรับ WROOM-DA และ AI Thinker ESP32-CAM

เตรียม Arduino IDE หรือ Arduino CLI พร้อม Arduino-ESP32 3.3.12 และ Python 3.11 ขึ้นไป
1. แตก ZIP ทั้งชุด ปิด Serial Monitor และต่อบอร์ดทีละตัว
2. บอร์ดหลักใช้ Install-WROOM-DA.cmd กล้องใช้ Install-CAM.cmd เลือกพอร์ตที่แสดงจริง
3. เมื่อคอมเปิดบัตร QR ให้สแกนใน AquaHatch 0.14.0 ขึ้นไปจากเมนูตั้งค่า แล้วเลือก Wi-Fi บ้าน
4. ผังขาบอร์ดหลัก DS18B20 GPIO4, RS485 TX16 / DE+RE17 / RX18, ADS1115 SDA21 / SCL22
5. ใช้ Read-QR-WROOM-DA.cmd หรือ Read-QR-CAM.cmd เพื่ออ่านบัตรเดิมผ่าน USB

ดู FIRST_BOOT_PAIRING_TH.md และ PH_ADS1115_SETUP_TH.md
เก็บบัตร QR ส่วนตัวไว้กับเจ้าของบอร์ด
